#!/usr/bin/env python
"""
Seed script - Run this to populate the database with demo data
Usage: python seed.py
"""
import sys
from pathlib import Path

# Add the backend directory to the path
sys.path.insert(0, str(Path(__file__).parent))

from app.utils.seed_data import seed_database

if __name__ == "__main__":
    print("🌱 ExpenseFlow Database Seeder")
    print("=" * 50)
    seed_database()
