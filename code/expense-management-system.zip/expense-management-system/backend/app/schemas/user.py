from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    company_name: Optional[str] = "My Company"
    country: Optional[str] = "United States"
    currency: Optional[str] = "USD"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str]
    role_id: Optional[int] = None
    company_id: Optional[int] = None
    manager_id: Optional[int] = None

    class Config:
        from_attributes = True

class UserCreateByAdmin(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    role: str  # Admin, Manager, Employee
    manager_id: Optional[int] = None

class UserUpdateByAdmin(BaseModel):
    full_name: Optional[str] = None
    role: Optional[str] = None
    manager_id: Optional[int] = None
    is_active: Optional[bool] = None
