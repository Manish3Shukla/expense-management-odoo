from pydantic import BaseModel
from typing import Optional, List

class ApprovalRuleCreate(BaseModel):
    name: str
    rule_type: str  # percentage, specific_approver, hybrid
    approval_percentage: Optional[float] = None
    specific_approver_id: Optional[int] = None
    is_manager_approver: bool = True
    approver_sequences: Optional[List[dict]] = None  # [{"approver_id": 1, "sequence": 1}, ...]

class ApprovalRuleOut(BaseModel):
    id: int
    name: str
    rule_type: str
    approval_percentage: Optional[float]
    specific_approver_id: Optional[int]
    is_manager_approver: bool

    class Config:
        from_attributes = True

class ApprovalDecision(BaseModel):
    decision: str  # approved or rejected
    comment: Optional[str] = None

class ApprovalStepOut(BaseModel):
    id: int
    expense_id: int
    approver_id: int
    sequence: int
    decision: str
    comment: Optional[str]

    class Config:
        from_attributes = True
