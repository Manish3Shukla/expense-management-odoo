from pydantic import BaseModel

class CompanyCreate(BaseModel):
    name: str
    country: str
    currency: str

class CompanyOut(BaseModel):
    id: int
    name: str
    country: str
    currency: str

    class Config:
        from_attributes = True
