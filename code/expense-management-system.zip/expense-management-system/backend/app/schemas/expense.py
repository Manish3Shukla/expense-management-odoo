from pydantic import BaseModel
from datetime import date
from typing import Optional

class ExpenseCreate(BaseModel):
    amount: float
    currency: str
    category: str
    description: Optional[str] = None
    date: date

class ExpenseOut(BaseModel):
    id: int
    amount: float
    currency: str
    category: str
    description: Optional[str]
    date: date
    status: str

    class Config:
        from_attributes = True
