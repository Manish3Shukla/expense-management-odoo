from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import SQLAlchemyError
from .db.session import Base, engine
from .api.api_v1.endpoints import auth, users, expenses, admin, approvals, countries
from .models import user as _user_model  # noqa: F401
from .models import role as _role_model  # noqa: F401
from .models import expense as _expense_model  # noqa: F401
from .models import approval as _approval_model  # noqa: F401
from .models import company as _company_model  # noqa: F401
from .models import approval_rule as _approval_rule_model  # noqa: F401
from .models import approval_sequence as _approval_sequence_model  # noqa: F401
from .utils.error_handlers import (
    validation_exception_handler,
    database_exception_handler,
    general_exception_handler
)
from .utils.logger import logger
from .core.config import get_settings
import time

settings = get_settings()

app = FastAPI(
    title="ExpenseFlow API",
    version="1.0.0",
    description="Smart Expense Management System with Approval Workflows",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Configuration
allowed_origins = settings.cors_origins if hasattr(settings, 'cors_origins') else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Exception Handlers
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(SQLAlchemyError, database_exception_handler)
app.add_exception_handler(Exception, general_exception_handler)

@app.middleware("http")
async def log_requests(request, call_next):
    """Log all requests"""
    start_time = time.time()
    
    logger.info(f"Request: {request.method} {request.url.path}")
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    logger.info(f"Response: {response.status_code} - {process_time:.2f}s")
    
    return response

@app.on_event("startup")
async def on_startup():
    """Initialize application on startup"""
    logger.info("Starting ExpenseFlow API...")
    
    # Create database tables
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Failed to create database tables: {str(e)}")
        raise
    
    logger.info("ExpenseFlow API started successfully")

@app.on_event("shutdown")
async def on_shutdown():
    """Cleanup on shutdown"""
    logger.info("Shutting down ExpenseFlow API...")

# Routers
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"]) 
app.include_router(users.router, prefix="/api/v1/users", tags=["Users"]) 
app.include_router(expenses.router, prefix="/api/v1/expenses", tags=["Expenses"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin"])
app.include_router(approvals.router, prefix="/api/v1/approvals", tags=["Approvals"])
app.include_router(countries.router, prefix="/api/v1/countries", tags=["Countries"]) 

@app.get("/", tags=["Root"])
async def root():
    """API root endpoint"""
    return {
        "message": "Welcome to ExpenseFlow API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health", tags=["Health"])
async def health():
    """Health check endpoint"""
    try:
        # Test database connection
        from .db.session import SessionLocal
        db = SessionLocal()
        db.execute("SELECT 1")
        db.close()
        
        return {
            "status": "healthy",
            "database": "connected",
            "version": "1.0.0"
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e)
        }
