"""
Seed data for testing and demonstration
Run this script to populate the database with sample data
"""
from sqlalchemy.orm import Session
from ..db.session import SessionLocal
from ..models.user import User
from ..models.role import Role
from ..models.company import Company
from ..models.expense import Expense, ExpenseStatus
from ..models.approval_rule import ApprovalRule, RuleType
from ..core.security import get_password_hash
from datetime import date, timedelta
import random

def seed_database():
    """Seed the database with sample data"""
    db = SessionLocal()
    
    try:
        print("🌱 Starting database seeding...")
        
        # Create roles
        print("Creating roles...")
        roles = {}
        for role_name in ["Admin", "Manager", "Employee"]:
            role = db.query(Role).filter(Role.name == role_name).first()
            if not role:
                role = Role(name=role_name)
                db.add(role)
                db.commit()
                db.refresh(role)
            roles[role_name] = role
        
        # Create company
        print("Creating company...")
        company = db.query(Company).first()
        if not company:
            company = Company(
                name="Demo Corp",
                country="United States",
                currency="USD"
            )
            db.add(company)
            db.commit()
            db.refresh(company)
        
        # Create users
        print("Creating users...")
        users_data = [
            {
                "email": "admin@demo.com",
                "password": "admin123",
                "full_name": "Admin User",
                "role": "Admin",
                "manager": None
            },
            {
                "email": "manager1@demo.com",
                "password": "manager123",
                "full_name": "John Manager",
                "role": "Manager",
                "manager": None
            },
            {
                "email": "manager2@demo.com",
                "password": "manager123",
                "full_name": "Sarah Manager",
                "role": "Manager",
                "manager": None
            },
            {
                "email": "employee1@demo.com",
                "password": "employee123",
                "full_name": "Alice Employee",
                "role": "Employee",
                "manager": "manager1@demo.com"
            },
            {
                "email": "employee2@demo.com",
                "password": "employee123",
                "full_name": "Bob Employee",
                "role": "Employee",
                "manager": "manager1@demo.com"
            },
            {
                "email": "employee3@demo.com",
                "password": "employee123",
                "full_name": "Charlie Employee",
                "role": "Employee",
                "manager": "manager2@demo.com"
            }
        ]
        
        created_users = {}
        for user_data in users_data:
            existing = db.query(User).filter(User.email == user_data["email"]).first()
            if not existing:
                user = User(
                    email=user_data["email"],
                    hashed_password=get_password_hash(user_data["password"]),
                    full_name=user_data["full_name"],
                    role_id=roles[user_data["role"]].id,
                    company_id=company.id
                )
                db.add(user)
                db.commit()
                db.refresh(user)
                created_users[user_data["email"]] = user
            else:
                created_users[user_data["email"]] = existing
        
        # Set managers
        print("Setting manager relationships...")
        for user_data in users_data:
            if user_data["manager"]:
                user = created_users[user_data["email"]]
                manager = created_users[user_data["manager"]]
                user.manager_id = manager.id
        db.commit()
        
        # Create approval rules
        print("Creating approval rules...")
        rules_data = [
            {
                "name": "Standard Approval (60%)",
                "rule_type": RuleType.percentage,
                "approval_percentage": 60.0,
                "is_manager_approver": True
            },
            {
                "name": "Manager Auto-Approve",
                "rule_type": RuleType.specific_approver,
                "specific_approver": "manager1@demo.com",
                "is_manager_approver": False
            },
            {
                "name": "Hybrid Rule (50% OR Manager)",
                "rule_type": RuleType.hybrid,
                "approval_percentage": 50.0,
                "specific_approver": "manager2@demo.com",
                "is_manager_approver": True
            }
        ]
        
        for rule_data in rules_data:
            existing = db.query(ApprovalRule).filter(ApprovalRule.name == rule_data["name"]).first()
            if not existing:
                specific_approver_id = None
                if "specific_approver" in rule_data:
                    approver = created_users.get(rule_data["specific_approver"])
                    if approver:
                        specific_approver_id = approver.id
                
                rule = ApprovalRule(
                    company_id=company.id,
                    name=rule_data["name"],
                    rule_type=rule_data["rule_type"],
                    approval_percentage=rule_data.get("approval_percentage"),
                    specific_approver_id=specific_approver_id,
                    is_manager_approver=rule_data["is_manager_approver"]
                )
                db.add(rule)
        db.commit()
        
        # Create sample expenses
        print("Creating sample expenses...")
        categories = ["Meal", "Travel", "Office", "Equipment", "Entertainment"]
        descriptions = [
            "Team lunch meeting",
            "Client dinner",
            "Flight to conference",
            "Hotel accommodation",
            "Office supplies",
            "New laptop",
            "Software subscription",
            "Team building event"
        ]
        
        employees = [u for u in created_users.values() if u.role_id == roles["Employee"].id]
        
        for employee in employees:
            # Create 3-5 expenses per employee
            num_expenses = random.randint(3, 5)
            for i in range(num_expenses):
                expense_date = date.today() - timedelta(days=random.randint(1, 30))
                status = random.choice([
                    ExpenseStatus.pending_approval,
                    ExpenseStatus.approved,
                    ExpenseStatus.rejected
                ])
                
                expense = Expense(
                    employee_id=employee.id,
                    amount=round(random.uniform(10, 500), 2),
                    currency="USD",
                    category=random.choice(categories),
                    description=random.choice(descriptions),
                    date=expense_date,
                    status=status
                )
                db.add(expense)
        
        db.commit()
        
        print("✅ Database seeding completed successfully!")
        print("\n📋 Demo Accounts Created:")
        print("=" * 50)
        for user_data in users_data:
            print(f"Email: {user_data['email']}")
            print(f"Password: {user_data['password']}")
            print(f"Role: {user_data['role']}")
            print("-" * 50)
        
    except Exception as e:
        print(f"❌ Error seeding database: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
