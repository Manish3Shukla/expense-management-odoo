import httpx
from ..core.config import get_settings

async def fetch_rates(base: str) -> dict:
    url = f"https://api.exchangerate-api.com/v4/latest/{base}"
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url)
        r.raise_for_status()
        return r.json()

async def convert_amount(amount: float, from_currency: str, to_currency: str) -> float:
    if from_currency.upper() == to_currency.upper():
        return amount
    data = await fetch_rates(from_currency.upper())
    rates = data.get("rates", {})
    rate = rates.get(to_currency.upper())
    if not rate:
        raise ValueError("Unsupported currency conversion")
    return amount * rate
