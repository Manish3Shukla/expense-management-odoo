from pydantic import BaseModel
from datetime import date

class OCRExpense(BaseModel):
    amount: float
    currency: str
    category: str
    description: str | None = None
    date: date

async def parse_receipt(file) -> OCRExpense:
    # Placeholder OCR logic; integrate pytesseract in production
    content = await file.read()
    # naive stub
    return OCRExpense(amount=10.0, currency="USD", category="Meal", description="OCR stub", date=date.today())
