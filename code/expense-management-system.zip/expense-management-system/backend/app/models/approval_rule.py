from sqlalchemy import String, ForeignKey, Integer, Boolean, Float, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db.session import Base
import enum

class RuleType(str, enum.Enum):
    percentage = "percentage"
    specific_approver = "specific_approver"
    hybrid = "hybrid"

class ApprovalRule(Base):
    __tablename__ = "approval_rules"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    rule_type: Mapped[RuleType] = mapped_column(Enum(RuleType), default=RuleType.percentage)
    
    # Percentage rule
    approval_percentage: Mapped[float | None] = mapped_column(Float, nullable=True)
    
    # Specific approver rule
    specific_approver_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # Manager approval flag
    is_manager_approver: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Multi-level approvers (stored as JSON in description for simplicity, or use separate table)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    
    company = relationship("Company")
    specific_approver = relationship("User", foreign_keys=[specific_approver_id])

class ApprovalFlow(Base):
    """Defines the sequence of approvers for an expense"""
    __tablename__ = "approval_flows"

    id: Mapped[int] = mapped_column(primary_key=True)
    expense_id: Mapped[int] = mapped_column(ForeignKey("expenses.id"), index=True, unique=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("approval_rules.id"), index=True)
    current_step: Mapped[int] = mapped_column(Integer, default=1)
    
    expense = relationship("Expense", back_populates="approval_flow")
    rule = relationship("ApprovalRule")
