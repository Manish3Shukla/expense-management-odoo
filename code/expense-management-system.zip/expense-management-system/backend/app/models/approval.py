from sqlalchemy import ForeignKey, Integer, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db.session import Base
import enum

class Decision(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"

class ApprovalStep(Base):
    __tablename__ = "approval_steps"

    id: Mapped[int] = mapped_column(primary_key=True)
    expense_id: Mapped[int] = mapped_column(ForeignKey("expenses.id"), index=True)
    approver_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    sequence: Mapped[int] = mapped_column(Integer, default=1)
    decision: Mapped[Decision] = mapped_column(Enum(Decision), default=Decision.pending)
    comment: Mapped[str | None] = mapped_column(Text)

    expense = relationship("Expense", back_populates="approval_steps")
    approver = relationship("User")
