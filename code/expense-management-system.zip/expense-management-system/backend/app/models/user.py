from sqlalchemy import String, ForeignKey, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db.session import Base

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str | None]
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    role_id: Mapped[int | None] = mapped_column(ForeignKey("roles.id"))
    company_id: Mapped[int | None] = mapped_column(ForeignKey("companies.id"), index=True)

    role = relationship("Role")
    company = relationship("Company")

    manager_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    manager = relationship("User", remote_side=[id])
