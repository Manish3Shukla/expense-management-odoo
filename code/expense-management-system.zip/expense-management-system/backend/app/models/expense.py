from sqlalchemy import String, ForeignKey, Numeric, Date, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db.session import Base
import enum

class ExpenseStatus(str, enum.Enum):
    draft = "draft"
    submitted = "submitted"
    pending_approval = "pending_approval"
    approved = "approved"
    rejected = "rejected"

class Expense(Base):
    __tablename__ = "expenses"

    id: Mapped[int] = mapped_column(primary_key=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    amount: Mapped[float] = mapped_column(Numeric(scale=2))
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    category: Mapped[str] = mapped_column(String(100))
    description: Mapped[str | None] = mapped_column(Text)
    date: Mapped[str] = mapped_column(Date)
    status: Mapped[ExpenseStatus] = mapped_column(Enum(ExpenseStatus), default=ExpenseStatus.draft)
    receipt_url: Mapped[str | None] = mapped_column(String(500), nullable=True)

    employee = relationship("User")
    approval_flow = relationship("ApprovalFlow", back_populates="expense", uselist=False)
    approval_steps = relationship("ApprovalStep", back_populates="expense")
