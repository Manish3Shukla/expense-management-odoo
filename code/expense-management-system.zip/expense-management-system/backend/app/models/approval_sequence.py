from sqlalchemy import ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db.session import Base

class ApprovalSequence(Base):
    """Defines the order of approvers in a multi-level approval"""
    __tablename__ = "approval_sequences"

    id: Mapped[int] = mapped_column(primary_key=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("approval_rules.id"), index=True)
    approver_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    
    rule = relationship("ApprovalRule")
    approver = relationship("User")
