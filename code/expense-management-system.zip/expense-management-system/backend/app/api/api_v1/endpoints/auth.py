from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ....db.session import get_db
from ....models.user import User
from ....models.role import Role
from ....models.company import Company
from ....core.security import create_access_token, get_password_hash, verify_password
from ....schemas.user import UserCreate, UserLogin, UserOut
from jose import JWTError

router = APIRouter()

@router.post("/register", response_model=UserOut)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Ensure roles exist
    for role_name in ["Admin", "Manager", "Employee"]:
        role = db.query(Role).filter(Role.name == role_name).first()
        if not role:
            db.add(Role(name=role_name))
    db.commit()
    
    role_admin = db.query(Role).filter(Role.name == "Admin").first()

    # Create company for first user
    company = Company(
        name=payload.company_name if hasattr(payload, 'company_name') else "My Company",
        country=payload.country if hasattr(payload, 'country') else "United States",
        currency=payload.currency if hasattr(payload, 'currency') else "USD"
    )
    db.add(company)
    db.commit()
    db.refresh(company)

    user = User(
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        full_name=payload.full_name,
        role_id=role_admin.id,
        company_id=company.id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.post("/login")
def login(payload: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_access_token(str(user.id))
    
    # Include user info in response
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role.name if user.role else None,
            "company_id": user.company_id
        }
    }
