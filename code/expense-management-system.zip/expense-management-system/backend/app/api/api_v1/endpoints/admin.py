from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ....db.session import get_db
from ....models.user import User
from ....models.role import Role
from ....models.approval_rule import ApprovalRule, ApprovalSequence
from ....models.company import Company
from ....schemas.user import UserOut, UserCreateByAdmin, UserUpdateByAdmin
from ....schemas.approval import ApprovalRuleCreate, ApprovalRuleOut
from ....schemas.company import CompanyOut
from .users import get_current_user
from ....core.security import get_password_hash

router = APIRouter()

def require_admin(current_user: User = Depends(get_current_user)):
    if not current_user.role or current_user.role.name != "Admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

@router.get("/users", response_model=List[UserOut])
def list_users(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    users = db.query(User).filter(User.company_id == admin.company_id).all()
    return users

@router.post("/users", response_model=UserOut)
def create_user(payload: UserCreateByAdmin, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already exists")
    
    role = db.query(Role).filter(Role.name == payload.role).first()
    if not role:
        raise HTTPException(status_code=400, detail="Invalid role")
    
    user = User(
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        full_name=payload.full_name,
        role_id=role.id,
        company_id=admin.company_id,
        manager_id=payload.manager_id
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.patch("/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, payload: UserUpdateByAdmin, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    user = db.get(User, user_id)
    if not user or user.company_id != admin.company_id:
        raise HTTPException(status_code=404, detail="User not found")
    
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.role is not None:
        role = db.query(Role).filter(Role.name == payload.role).first()
        if role:
            user.role_id = role.id
    if payload.manager_id is not None:
        user.manager_id = payload.manager_id
    if payload.is_active is not None:
        user.is_active = payload.is_active
    
    db.commit()
    db.refresh(user)
    return user

@router.get("/company", response_model=CompanyOut)
def get_company(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    company = db.get(Company, admin.company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company

@router.get("/approval-rules", response_model=List[ApprovalRuleOut])
def list_approval_rules(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    rules = db.query(ApprovalRule).filter(ApprovalRule.company_id == admin.company_id).all()
    return rules

@router.post("/approval-rules", response_model=ApprovalRuleOut)
def create_approval_rule(payload: ApprovalRuleCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    rule = ApprovalRule(
        company_id=admin.company_id,
        name=payload.name,
        rule_type=payload.rule_type,
        approval_percentage=payload.approval_percentage,
        specific_approver_id=payload.specific_approver_id,
        is_manager_approver=payload.is_manager_approver
    )
    db.add(rule)
    db.commit()
    db.refresh(rule)
    
    # Add approval sequences if provided
    if payload.approver_sequences:
        for seq in payload.approver_sequences:
            approval_seq = ApprovalSequence(
                rule_id=rule.id,
                approver_id=seq["approver_id"],
                sequence=seq["sequence"]
            )
            db.add(approval_seq)
        db.commit()
    
    return rule
