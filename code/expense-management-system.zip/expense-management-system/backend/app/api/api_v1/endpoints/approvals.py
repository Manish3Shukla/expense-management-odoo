from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ....db.session import get_db
from ....models.user import User
from ....models.expense import Expense, ExpenseStatus
from ....models.approval import ApprovalStep, Decision
from ....models.approval_rule import ApprovalFlow, ApprovalRule, ApprovalSequence
from ....schemas.approval import ApprovalDecision, ApprovalStepOut
from .users import get_current_user

router = APIRouter()

@router.get("/pending", response_model=List[dict])
def get_pending_approvals(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Get expenses waiting for current user's approval"""
    pending = db.query(ApprovalStep).filter(
        ApprovalStep.approver_id == current_user.id,
        ApprovalStep.decision == Decision.pending
    ).all()
    
    result = []
    for step in pending:
        expense = step.expense
        result.append({
            "step_id": step.id,
            "expense_id": expense.id,
            "amount": float(expense.amount),
            "currency": expense.currency,
            "category": expense.category,
            "description": expense.description,
            "date": str(expense.date),
            "employee_name": expense.employee.full_name,
            "sequence": step.sequence
        })
    return result

@router.post("/{step_id}/decide")
def make_decision(step_id: int, payload: ApprovalDecision, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Approve or reject an expense"""
    step = db.get(ApprovalStep, step_id)
    if not step or step.approver_id != current_user.id:
        raise HTTPException(status_code=404, detail="Approval step not found")
    
    if step.decision != Decision.pending:
        raise HTTPException(status_code=400, detail="Already decided")
    
    # Update decision
    if payload.decision == "approved":
        step.decision = Decision.approved
    elif payload.decision == "rejected":
        step.decision = Decision.rejected
    else:
        raise HTTPException(status_code=400, detail="Invalid decision")
    
    step.comment = payload.comment
    db.commit()
    
    expense = step.expense
    
    # Check if rejected
    if step.decision == Decision.rejected:
        expense.status = ExpenseStatus.rejected
        db.commit()
        return {"status": "rejected", "message": "Expense rejected"}
    
    # Check approval flow logic
    flow = expense.approval_flow
    if flow:
        rule = flow.rule
        
        # Get all steps for this expense
        all_steps = db.query(ApprovalStep).filter(ApprovalStep.expense_id == expense.id).all()
        approved_count = sum(1 for s in all_steps if s.decision == Decision.approved)
        total_count = len(all_steps)
        
        # Check specific approver rule
        if rule.rule_type in ["specific_approver", "hybrid"]:
            if rule.specific_approver_id and step.approver_id == rule.specific_approver_id:
                expense.status = ExpenseStatus.approved
                db.commit()
                return {"status": "approved", "message": "Auto-approved by specific approver"}
        
        # Check percentage rule
        if rule.rule_type in ["percentage", "hybrid"]:
            if rule.approval_percentage and total_count > 0:
                approval_rate = (approved_count / total_count) * 100
                if approval_rate >= rule.approval_percentage:
                    expense.status = ExpenseStatus.approved
                    db.commit()
                    return {"status": "approved", "message": f"Approved by {approval_rate:.0f}% of approvers"}
        
        # Check if all pending steps are done
        pending_steps = [s for s in all_steps if s.decision == Decision.pending]
        if not pending_steps:
            # All steps decided, check if any rejected
            rejected_steps = [s for s in all_steps if s.decision == Decision.rejected]
            if rejected_steps:
                expense.status = ExpenseStatus.rejected
            else:
                expense.status = ExpenseStatus.approved
            db.commit()
            return {"status": expense.status.value, "message": "All approvals completed"}
        
        # Move to next step
        next_step = min(pending_steps, key=lambda s: s.sequence)
        flow.current_step = next_step.sequence
        db.commit()
        return {"status": "pending", "message": f"Moved to step {next_step.sequence}"}
    
    # No flow, simple approval
    expense.status = ExpenseStatus.approved
    db.commit()
    return {"status": "approved", "message": "Expense approved"}
