from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List
from ....db.session import get_db
from ....models.expense import Expense, ExpenseStatus
from ....models.user import User
from ....models.approval import ApprovalStep, Decision
from ....models.approval_rule import ApprovalFlow, ApprovalRule, ApprovalSequence
from .users import get_current_user
from ....schemas.expense import ExpenseCreate, ExpenseOut
from ....services.currency import convert_amount
from ....services.ocr import parse_receipt

router = APIRouter()

def create_approval_workflow(expense: Expense, employee: User, db: Session):
    """Create approval workflow for an expense"""
    # Get default rule for company (simplified - use first rule)
    rule = db.query(ApprovalRule).filter(ApprovalRule.company_id == employee.company_id).first()
    
    if not rule:
        # No rule, auto-approve or use manager
        if employee.manager_id:
            step = ApprovalStep(
                expense_id=expense.id,
                approver_id=employee.manager_id,
                sequence=1,
                decision=Decision.pending
            )
            db.add(step)
        return
    
    # Create approval flow
    flow = ApprovalFlow(
        expense_id=expense.id,
        rule_id=rule.id,
        current_step=1
    )
    db.add(flow)
    
    # Create approval steps based on rule
    sequence_num = 1
    
    # Add manager if required
    if rule.is_manager_approver and employee.manager_id:
        step = ApprovalStep(
            expense_id=expense.id,
            approver_id=employee.manager_id,
            sequence=sequence_num,
            decision=Decision.pending
        )
        db.add(step)
        sequence_num += 1
    
    # Add multi-level approvers from sequences
    sequences = db.query(ApprovalSequence).filter(ApprovalSequence.rule_id == rule.id).order_by(ApprovalSequence.sequence).all()
    for seq in sequences:
        step = ApprovalStep(
            expense_id=expense.id,
            approver_id=seq.approver_id,
            sequence=sequence_num,
            decision=Decision.pending
        )
        db.add(step)
        sequence_num += 1

@router.post("/", response_model=ExpenseOut)
def create_expense(payload: ExpenseCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    expense = Expense(
        employee_id=current_user.id,
        amount=payload.amount,
        currency=payload.currency,
        category=payload.category,
        description=payload.description,
        date=payload.date,
        status=ExpenseStatus.pending_approval,
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    
    # Create approval workflow
    create_approval_workflow(expense, current_user, db)
    db.commit()
    
    return expense

@router.get("/", response_model=List[dict])
def list_my_expenses(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    items = db.query(Expense).filter(Expense.employee_id == current_user.id).order_by(Expense.id.desc()).all()
    result = []
    for exp in items:
        # Get approval steps
        steps = db.query(ApprovalStep).filter(ApprovalStep.expense_id == exp.id).all()
        result.append({
            "id": exp.id,
            "amount": float(exp.amount),
            "currency": exp.currency,
            "category": exp.category,
            "description": exp.description,
            "date": str(exp.date),
            "status": exp.status.value,
            "approval_steps": [
                {
                    "approver_name": step.approver.full_name,
                    "decision": step.decision.value,
                    "comment": step.comment
                } for step in steps
            ]
        })
    return result

@router.get("/all", response_model=List[dict])
def list_all_expenses(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Admin/Manager view of all expenses in company"""
    if not current_user.role or current_user.role.name not in ["Admin", "Manager"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    items = db.query(Expense).join(User).filter(User.company_id == current_user.company_id).order_by(Expense.id.desc()).all()
    result = []
    for exp in items:
        steps = db.query(ApprovalStep).filter(ApprovalStep.expense_id == exp.id).all()
        
        # Convert amount to company currency
        company_currency = current_user.company.currency if current_user.company else "USD"
        converted_amount = float(exp.amount)  # Simplified, use currency service in production
        
        result.append({
            "id": exp.id,
            "employee_name": exp.employee.full_name,
            "employee_email": exp.employee.email,
            "amount": float(exp.amount),
            "currency": exp.currency,
            "amount_in_company_currency": converted_amount,
            "company_currency": company_currency,
            "category": exp.category,
            "description": exp.description,
            "date": str(exp.date),
            "status": exp.status.value,
            "approval_steps": [
                {
                    "approver_name": step.approver.full_name,
                    "decision": step.decision.value,
                    "comment": step.comment,
                    "sequence": step.sequence
                } for step in steps
            ]
        })
    return result

@router.post("/ocr")
async def create_expense_from_receipt(file: UploadFile = File(...), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    data = await parse_receipt(file)
    expense = Expense(
        employee_id=current_user.id,
        amount=data.amount,
        currency=data.currency,
        category=data.category,
        description=data.description,
        date=data.date,
        status=ExpenseStatus.pending_approval,
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    
    # Create approval workflow
    create_approval_workflow(expense, current_user, db)
    db.commit()
    
    return {
        "id": expense.id,
        "amount": float(expense.amount),
        "currency": expense.currency,
        "category": expense.category,
        "description": expense.description,
        "date": str(expense.date),
        "status": expense.status.value
    }
