from fastapi import APIRouter
import httpx

router = APIRouter()

@router.get("/")
async def get_countries():
    """Fetch all countries with their currencies"""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get("https://restcountries.com/v3.1/all?fields=name,currencies")
        r.raise_for_status()
        data = r.json()
        
        # Format for frontend
        countries = []
        for country in data:
            name = country.get("name", {}).get("common", "Unknown")
            currencies = country.get("currencies", {})
            currency_code = list(currencies.keys())[0] if currencies else "USD"
            countries.append({
                "name": name,
                "currency": currency_code
            })
        
        return sorted(countries, key=lambda x: x["name"])
