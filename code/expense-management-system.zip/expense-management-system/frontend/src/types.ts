export interface User {
  id: number
  email: string
  full_name: string | null
  role: string | null
  company_id: number | null
}

export interface Expense {
  id: number
  amount: number
  currency: string
  category: string
  description: string | null
  date: string
  status: string
  approval_steps?: ApprovalStep[]
  employee_name?: string
  employee_email?: string
}

export interface ApprovalStep {
  approver_name: string
  decision: string
  comment: string | null
  sequence?: number
}

export interface PendingApproval {
  step_id: number
  expense_id: number
  amount: number
  currency: string
  category: string
  description: string | null
  date: string
  employee_name: string
  sequence: number
}

export interface Country {
  name: string
  currency: string
}
