import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import Layout from '../components/Layout'

interface User {
  id: number
  email: string
  full_name: string | null
  role_id: number | null
  manager_id: number | null
}

interface ApprovalRule {
  id: number
  name: string
  rule_type: string
  approval_percentage: number | null
  specific_approver_id: number | null
  is_manager_approver: boolean
}

export default function Admin() {
  const [activeTab, setActiveTab] = useState<'users' | 'rules'>('users')
  const [showUserForm, setShowUserForm] = useState(false)
  const [showRuleForm, setShowRuleForm] = useState(false)
  const queryClient = useQueryClient()

  const [userForm, setUserForm] = useState({
    email: '',
    password: '',
    full_name: '',
    role: 'Employee',
    manager_id: ''
  })

  const [ruleForm, setRuleForm] = useState({
    name: '',
    rule_type: 'percentage',
    approval_percentage: '60',
    specific_approver_id: '',
    is_manager_approver: true
  })

  const { data: users } = useQuery<User[]>({
    queryKey: ['admin-users'],
    queryFn: async () => {
      const res = await api.get('/admin/users')
      return res.data
    }
  })

  const { data: rules } = useQuery<ApprovalRule[]>({
    queryKey: ['approval-rules'],
    queryFn: async () => {
      const res = await api.get('/admin/approval-rules')
      return res.data
    }
  })

  const createUserMutation = useMutation({
    mutationFn: async (data: typeof userForm) => {
      return api.post('/admin/users', {
        ...data,
        manager_id: data.manager_id ? parseInt(data.manager_id) : null
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-users'] })
      setShowUserForm(false)
      setUserForm({ email: '', password: '', full_name: '', role: 'Employee', manager_id: '' })
    }
  })

  const createRuleMutation = useMutation({
    mutationFn: async (data: typeof ruleForm) => {
      return api.post('/admin/approval-rules', {
        name: data.name,
        rule_type: data.rule_type,
        approval_percentage: data.approval_percentage ? parseFloat(data.approval_percentage) : null,
        specific_approver_id: data.specific_approver_id ? parseInt(data.specific_approver_id) : null,
        is_manager_approver: data.is_manager_approver
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['approval-rules'] })
      setShowRuleForm(false)
      setRuleForm({ name: '', rule_type: 'percentage', approval_percentage: '60', specific_approver_id: '', is_manager_approver: true })
    }
  })

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    createUserMutation.mutate(userForm)
  }

  const handleRuleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    createRuleMutation.mutate(ruleForm)
  }

  const managers = users?.filter(u => u.role_id === 2) || [] // Assuming role_id 2 is Manager

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Manage users and approval workflows</p>
        </div>

        <div className="flex space-x-2 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-6 py-3 font-medium transition-colors ${
              activeTab === 'users'
                ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400'
                : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white'
            }`}
          >
            Users
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-6 py-3 font-medium transition-colors ${
              activeTab === 'rules'
                ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400'
                : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white'
            }`}
          >
            Approval Rules
          </button>
        </div>

        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex justify-end">
              <button
                onClick={() => setShowUserForm(!showUserForm)}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all"
              >
                {showUserForm ? 'Cancel' : '+ Add User'}
              </button>
            </div>

            {showUserForm && (
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Create New User</h2>
                <form onSubmit={handleUserSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label>
                    <input
                      type="email"
                      value={userForm.email}
                      onChange={e => setUserForm({ ...userForm, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label>
                    <input
                      type="password"
                      value={userForm.password}
                      onChange={e => setUserForm({ ...userForm, password: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={userForm.full_name}
                      onChange={e => setUserForm({ ...userForm, full_name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Role</label>
                    <select
                      value={userForm.role}
                      onChange={e => setUserForm({ ...userForm, role: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="Employee">Employee</option>
                      <option value="Manager">Manager</option>
                      <option value="Admin">Admin</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Manager (optional)</label>
                    <select
                      value={userForm.manager_id}
                      onChange={e => setUserForm({ ...userForm, manager_id: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">No Manager</option>
                      {managers.map(m => (
                        <option key={m.id} value={m.id}>{m.full_name || m.email}</option>
                      ))}
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <button
                      type="submit"
                      disabled={createUserMutation.isPending}
                      className="w-full py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 transition-all"
                    >
                      {createUserMutation.isPending ? 'Creating...' : 'Create User'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Users</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Name</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Role</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Manager</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {users?.map(user => (
                      <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="px-6 py-4 whitespace-nowrap text-gray-900 dark:text-white">
                          {user.full_name || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-600 dark:text-gray-400">
                          {user.email}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                            {user.role_id === 1 ? 'Admin' : user.role_id === 2 ? 'Manager' : 'Employee'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-600 dark:text-gray-400">
                          {user.manager_id ? users.find(u => u.id === user.manager_id)?.full_name || 'Unknown' : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'rules' && (
          <div className="space-y-6">
            <div className="flex justify-end">
              <button
                onClick={() => setShowRuleForm(!showRuleForm)}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all"
              >
                {showRuleForm ? 'Cancel' : '+ Add Rule'}
              </button>
            </div>

            {showRuleForm && (
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Create Approval Rule</h2>
                <form onSubmit={handleRuleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Rule Name</label>
                    <input
                      type="text"
                      value={ruleForm.name}
                      onChange={e => setRuleForm({ ...ruleForm, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Rule Type</label>
                    <select
                      value={ruleForm.rule_type}
                      onChange={e => setRuleForm({ ...ruleForm, rule_type: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="percentage">Percentage Based</option>
                      <option value="specific_approver">Specific Approver</option>
                      <option value="hybrid">Hybrid (Both)</option>
                    </select>
                  </div>
                  {(ruleForm.rule_type === 'percentage' || ruleForm.rule_type === 'hybrid') && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Approval Percentage (%)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="100"
                        value={ruleForm.approval_percentage}
                        onChange={e => setRuleForm({ ...ruleForm, approval_percentage: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                  )}
                  {(ruleForm.rule_type === 'specific_approver' || ruleForm.rule_type === 'hybrid') && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Specific Approver
                      </label>
                      <select
                        value={ruleForm.specific_approver_id}
                        onChange={e => setRuleForm({ ...ruleForm, specific_approver_id: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        <option value="">Select Approver</option>
                        {users?.filter(u => u.role_id !== 3).map(u => (
                          <option key={u.id} value={u.id}>{u.full_name || u.email}</option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      checked={ruleForm.is_manager_approver}
                      onChange={e => setRuleForm({ ...ruleForm, is_manager_approver: e.target.checked })}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <label className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                      Require manager approval first
                    </label>
                  </div>
                  <button
                    type="submit"
                    disabled={createRuleMutation.isPending}
                    className="w-full py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 transition-all"
                  >
                    {createRuleMutation.isPending ? 'Creating...' : 'Create Rule'}
                  </button>
                </form>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {rules?.map(rule => (
                <div key={rule.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{rule.name}</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Type:</span>
                      <span className="font-medium text-gray-900 dark:text-white capitalize">{rule.rule_type.replace('_', ' ')}</span>
                    </div>
                    {rule.approval_percentage && (
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Approval %:</span>
                        <span className="font-medium text-gray-900 dark:text-white">{rule.approval_percentage}%</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Manager Approval:</span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        rule.is_manager_approver 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                          : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                      }`}>
                        {rule.is_manager_approver ? 'Required' : 'Not Required'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  )
}
