import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import Layout from '../components/Layout'
import { PendingApproval } from '../types'

export default function Approvals() {
  const [selectedExpense, setSelectedExpense] = useState<PendingApproval | null>(null)
  const [comment, setComment] = useState('')
  const queryClient = useQueryClient()

  const { data: pending, isLoading } = useQuery<PendingApproval[]>({
    queryKey: ['pending-approvals'],
    queryFn: async () => {
      const res = await api.get('/approvals/pending')
      return res.data
    }
  })

  const decideMutation = useMutation({
    mutationFn: async ({ stepId, decision }: { stepId: number, decision: string }) => {
      return api.post(`/approvals/${stepId}/decide`, { decision, comment })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-approvals'] })
      queryClient.invalidateQueries({ queryKey: ['all-expenses'] })
      setSelectedExpense(null)
      setComment('')
    }
  })

  const handleDecision = (decision: 'approved' | 'rejected') => {
    if (selectedExpense) {
      decideMutation.mutate({ stepId: selectedExpense.step_id, decision })
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Pending Approvals</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Review and approve expense claims</p>
        </div>

        {isLoading ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center">
            <div className="text-gray-500">Loading approvals...</div>
          </div>
        ) : pending && pending.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              {pending.map(item => (
                <div
                  key={item.step_id}
                  onClick={() => setSelectedExpense(item)}
                  className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm border-2 p-6 cursor-pointer transition-all hover:shadow-lg ${
                    selectedExpense?.step_id === item.step_id
                      ? 'border-blue-500 dark:border-blue-400'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-2xl">{getCategoryIcon(item.category)}</span>
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{item.category}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">by {item.employee_name}</p>
                        </div>
                      </div>
                      {item.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{item.description}</p>
                      )}
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500 dark:text-gray-400">
                        <span>📅 {item.date}</span>
                        <span>Step {item.sequence}</span>
                      </div>
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-xl font-bold text-gray-900 dark:text-white">
                        {item.currency} {item.amount.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg:sticky lg:top-8 h-fit">
              {selectedExpense ? (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Review Expense</h2>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700">
                      <span className="text-gray-600 dark:text-gray-400">Employee</span>
                      <span className="font-medium text-gray-900 dark:text-white">{selectedExpense.employee_name}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700">
                      <span className="text-gray-600 dark:text-gray-400">Amount</span>
                      <span className="font-bold text-gray-900 dark:text-white text-lg">
                        {selectedExpense.currency} {selectedExpense.amount.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700">
                      <span className="text-gray-600 dark:text-gray-400">Category</span>
                      <span className="font-medium text-gray-900 dark:text-white">{selectedExpense.category}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700">
                      <span className="text-gray-600 dark:text-gray-400">Date</span>
                      <span className="font-medium text-gray-900 dark:text-white">{selectedExpense.date}</span>
                    </div>
                    {selectedExpense.description && (
                      <div className="py-3">
                        <span className="text-gray-600 dark:text-gray-400 block mb-2">Description</span>
                        <p className="text-gray-900 dark:text-white">{selectedExpense.description}</p>
                      </div>
                    )}
                  </div>

                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Comment (optional)
                    </label>
                    <textarea
                      value={comment}
                      onChange={e => setComment(e.target.value)}
                      rows={3}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Add a comment about your decision..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => handleDecision('rejected')}
                      disabled={decideMutation.isPending}
                      className="py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 disabled:opacity-50 transition-all"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleDecision('approved')}
                      disabled={decideMutation.isPending}
                      className="py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 disabled:opacity-50 transition-all"
                    >
                      Approve
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-8 text-center">
                  <div className="text-6xl mb-4">👈</div>
                  <p className="text-gray-600 dark:text-gray-400">Select an expense to review</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
            <div className="text-6xl mb-4">✅</div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">All caught up!</h3>
            <p className="text-gray-600 dark:text-gray-400">No pending approvals at the moment</p>
          </div>
        )}
      </div>
    </Layout>
  )
}

function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    'Meal': '🍽️',
    'Travel': '✈️',
    'Office': '🏢',
    'Equipment': '💻',
    'Entertainment': '🎭',
    'Other': '📦'
  }
  return icons[category] || '📄'
}
