import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'
import Layout from '../components/Layout'
import { Expense } from '../types'

export default function AllExpenses() {
  const [filter, setFilter] = useState<string>('all')
  const [search, setSearch] = useState('')

  const { data: expenses, isLoading } = useQuery<Expense[]>({
    queryKey: ['all-expenses'],
    queryFn: async () => {
      const res = await api.get('/expenses/all')
      return res.data
    }
  })

  const filteredExpenses = expenses?.filter(exp => {
    const matchesFilter = filter === 'all' || exp.status === filter
    const matchesSearch = !search || 
      exp.employee_name?.toLowerCase().includes(search.toLowerCase()) ||
      exp.category.toLowerCase().includes(search.toLowerCase()) ||
      exp.description?.toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  }) || []

  const stats = {
    total: expenses?.length || 0,
    pending: expenses?.filter(e => e.status === 'pending_approval').length || 0,
    approved: expenses?.filter(e => e.status === 'approved').length || 0,
    rejected: expenses?.filter(e => e.status === 'rejected').length || 0,
    totalAmount: expenses?.reduce((sum, e) => sum + e.amount, 0) || 0
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">All Expenses</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Company-wide expense overview</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-sm p-6 text-white">
            <p className="text-sm opacity-90">Total Expenses</p>
            <p className="text-3xl font-bold mt-2">{stats.total}</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl shadow-sm p-6 text-white">
            <p className="text-sm opacity-90">Pending</p>
            <p className="text-3xl font-bold mt-2">{stats.pending}</p>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl shadow-sm p-6 text-white">
            <p className="text-sm opacity-90">Approved</p>
            <p className="text-3xl font-bold mt-2">{stats.approved}</p>
          </div>
          <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-sm p-6 text-white">
            <p className="text-sm opacity-90">Rejected</p>
            <p className="text-3xl font-bold mt-2">{stats.rejected}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl shadow-sm p-6 text-white">
            <p className="text-sm opacity-90">Total Amount</p>
            <p className="text-2xl font-bold mt-2">${stats.totalAmount.toFixed(0)}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
              <div className="flex items-center space-x-4">
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search expenses..."
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                {['all', 'pending_approval', 'approved', 'rejected'].map(status => (
                  <button
                    key={status}
                    onClick={() => setFilter(status)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      filter === status
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
                    }`}
                  >
                    {status === 'all' ? 'All' : status.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="p-8 text-center text-gray-500">Loading expenses...</div>
          ) : filteredExpenses.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-700/50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Employee</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Approvals</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredExpenses.map(expense => (
                    <tr key={expense.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{expense.employee_name}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{expense.employee_email}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <span className="text-xl">{getCategoryIcon(expense.category)}</span>
                          <span className="text-gray-900 dark:text-white">{expense.category}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 dark:text-white max-w-xs truncate">
                          {expense.description || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-semibold text-gray-900 dark:text-white">
                          {expense.currency} {expense.amount.toFixed(2)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {expense.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(expense.status)}`}>
                          {expense.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {expense.approval_steps && expense.approval_steps.length > 0 ? (
                          <div className="space-y-1">
                            {expense.approval_steps.map((step, idx) => (
                              <div key={idx} className="flex items-center space-x-2 text-xs">
                                <span className={`w-2 h-2 rounded-full ${
                                  step.decision === 'approved' ? 'bg-green-500' :
                                  step.decision === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'
                                }`} />
                                <span className="text-gray-600 dark:text-gray-400">
                                  {step.approver_name}
                                </span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500 dark:text-gray-400">
              No expenses found matching your criteria
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}

function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    'Meal': '🍽️',
    'Travel': '✈️',
    'Office': '🏢',
    'Equipment': '💻',
    'Entertainment': '🎭',
    'Other': '📦'
  }
  return icons[category] || '📄'
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    'draft': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    'submitted': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
    'pending_approval': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
    'approved': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
    'rejected': 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
  }
  return colors[status] || colors['draft']
}
