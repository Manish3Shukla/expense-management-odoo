import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import Layout from '../components/Layout'
import { Expense } from '../types'

export default function Expenses() {
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    amount: '',
    currency: 'USD',
    category: 'Meal',
    description: '',
    date: new Date().toISOString().split('T')[0]
  })
  const queryClient = useQueryClient()

  const { data: expenses, isLoading } = useQuery<Expense[]>({
    queryKey: ['my-expenses'],
    queryFn: async () => {
      const res = await api.get('/expenses/')
      return res.data
    }
  })

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return api.post('/expenses/', {
        ...data,
        amount: parseFloat(data.amount)
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-expenses'] })
      setShowForm(false)
      setFormData({
        amount: '',
        currency: 'USD',
        category: 'Meal',
        description: '',
        date: new Date().toISOString().split('T')[0]
      })
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    createMutation.mutate(formData)
  }

  const categories = ['Meal', 'Travel', 'Office', 'Equipment', 'Entertainment', 'Other']
  const currencies = ['USD', 'EUR', 'GBP', 'INR', 'JPY', 'AUD', 'CAD']

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">My Expenses</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">Track and manage your expense claims</p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 focus:ring-4 focus:ring-blue-300 transition-all transform hover:scale-105"
          >
            {showForm ? 'Cancel' : '+ New Expense'}
          </button>
        </div>

        {showForm && (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Create New Expense</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={e => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Currency</label>
                <select
                  value={formData.currency}
                  onChange={e => setFormData({ ...formData, currency: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  {currencies.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category</label>
                <select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={e => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label>
                <textarea
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Add details about this expense..."
                />
              </div>
              <div className="md:col-span-2">
                <button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="w-full py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 transition-all"
                >
                  {createMutation.isPending ? 'Creating...' : 'Submit Expense'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Expense History</h2>
          </div>
          {isLoading ? (
            <div className="p-8 text-center text-gray-500">Loading...</div>
          ) : expenses && expenses.length > 0 ? (
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {expenses.map(expense => (
                <div key={expense.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-2xl">{getCategoryIcon(expense.category)}</span>
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{expense.category}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{expense.date}</p>
                        </div>
                      </div>
                      {expense.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 ml-11">{expense.description}</p>
                      )}
                      {expense.approval_steps && expense.approval_steps.length > 0 && (
                        <div className="ml-11 mt-3 space-y-1">
                          {expense.approval_steps.map((step, idx) => (
                            <div key={idx} className="flex items-center space-x-2 text-sm">
                              <span className={`w-2 h-2 rounded-full ${
                                step.decision === 'approved' ? 'bg-green-500' :
                                step.decision === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'
                              }`} />
                              <span className="text-gray-600 dark:text-gray-400">
                                {step.approver_name}: <span className="font-medium">{step.decision}</span>
                                {step.comment && <span className="italic"> - {step.comment}</span>}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-xl font-bold text-gray-900 dark:text-white">
                        {expense.currency} {expense.amount.toFixed(2)}
                      </p>
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mt-2 ${getStatusColor(expense.status)}`}>
                        {expense.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500 dark:text-gray-400">
              No expenses yet. Click "New Expense" to create your first one!
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}

function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    'Meal': '🍽️',
    'Travel': '✈️',
    'Office': '🏢',
    'Equipment': '💻',
    'Entertainment': '🎭',
    'Other': '📦'
  }
  return icons[category] || '📄'
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    'draft': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    'submitted': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
    'pending_approval': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
    'approved': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
    'rejected': 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
  }
  return colors[status] || colors['draft']
}
