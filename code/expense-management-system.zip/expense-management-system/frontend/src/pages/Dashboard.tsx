import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'
import { useAuth } from '../contexts/AuthContext'
import Layout from '../components/Layout'
import { Expense, PendingApproval } from '../types'

export default function Dashboard() {
  const { user } = useAuth()

  const { data: myExpenses } = useQuery<Expense[]>({
    queryKey: ['my-expenses'],
    queryFn: async () => {
      const res = await api.get('/expenses/')
      return res.data
    }
  })

  const { data: pendingApprovals } = useQuery<PendingApproval[]>({
    queryKey: ['pending-approvals'],
    queryFn: async () => {
      const res = await api.get('/approvals/pending')
      return res.data
    },
    enabled: user?.role === 'Manager' || user?.role === 'Admin'
  })

  const stats = [
    {
      label: 'Total Expenses',
      value: myExpenses?.length || 0,
      color: 'from-blue-500 to-blue-600',
      icon: '📊'
    },
    {
      label: 'Pending Approval',
      value: myExpenses?.filter(e => e.status === 'pending_approval').length || 0,
      color: 'from-yellow-500 to-orange-500',
      icon: '⏳'
    },
    {
      label: 'Approved',
      value: myExpenses?.filter(e => e.status === 'approved').length || 0,
      color: 'from-green-500 to-emerald-600',
      icon: '✅'
    },
    {
      label: 'Awaiting My Approval',
      value: pendingApprovals?.length || 0,
      color: 'from-purple-500 to-pink-600',
      icon: '👤'
    }
  ]

  const recentExpenses = myExpenses?.slice(0, 5) || []

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Welcome back, {user?.full_name || user?.email}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => (
            <div key={idx} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white mt-2">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center text-2xl`}>
                  {stat.icon}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Recent Expenses</h2>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {recentExpenses.length === 0 ? (
              <div className="p-8 text-center text-gray-500 dark:text-gray-400">
                No expenses yet. Create your first expense to get started!
              </div>
            ) : (
              recentExpenses.map(expense => (
                <div key={expense.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{getCategoryIcon(expense.category)}</span>
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{expense.category}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{expense.description}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-gray-900 dark:text-white">
                        {expense.currency} {expense.amount.toFixed(2)}
                      </p>
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(expense.status)}`}>
                        {expense.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Layout>
  )
}

function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    'Meal': '🍽️',
    'Travel': '✈️',
    'Office': '🏢',
    'Equipment': '💻',
    'Entertainment': '🎭',
    'Other': '📦'
  }
  return icons[category] || '📄'
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    'draft': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    'submitted': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
    'pending_approval': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
    'approved': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
    'rejected': 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
  }
  return colors[status] || colors['draft']
}
