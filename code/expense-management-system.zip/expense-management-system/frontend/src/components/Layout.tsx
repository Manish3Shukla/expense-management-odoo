import { ReactNode } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { useTheme } from '../contexts/ThemeContext'

interface LayoutProps {
  children: ReactNode
}

export default function Layout({ children }: LayoutProps) {
  const { user, logout } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const location = useLocation()

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊', roles: ['Admin', 'Manager', 'Employee'] },
    { path: '/expenses', label: 'My Expenses', icon: '💰', roles: ['Employee', 'Manager', 'Admin'] },
    { path: '/approvals', label: 'Approvals', icon: '✅', roles: ['Manager', 'Admin'] },
    { path: '/all-expenses', label: 'All Expenses', icon: '📈', roles: ['Manager', 'Admin'] },
    { path: '/admin', label: 'Admin', icon: '⚙️', roles: ['Admin'] },
  ]

  const visibleItems = navItems.filter(item => 
    !user?.role || item.roles.includes(user.role)
  )

  return (
    <div className="min-h-screen bg-white dark:bg-[#0d1117] transition-colors duration-200">
      {/* Canva-style light / GitHub-style dark navbar */}
      <nav className="bg-white dark:bg-[#161b22] border-b border-gray-200 dark:border-[#30363d] sticky top-0 z-50 backdrop-blur-sm bg-opacity-90 dark:bg-opacity-90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center space-x-8">
              <Link to="/dashboard" className="flex items-center space-x-3 group">
                <div className="w-10 h-10 bg-gradient-to-br from-[#7d2ae8] to-[#00c4cc] dark:from-[#238636] dark:to-[#2f81f7] rounded-xl flex items-center justify-center transform group-hover:scale-110 transition-transform">
                  <span className="text-white font-bold text-lg">E</span>
                </div>
                <div>
                  <span className="font-bold text-gray-900 dark:text-[#e6edf3] text-lg block leading-tight">ExpenseFlow</span>
                  <span className="text-xs text-gray-500 dark:text-[#8b949e]">Smart Expense Management</span>
                </div>
              </Link>
              <div className="hidden lg:flex space-x-1">
                {visibleItems.map(item => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center space-x-2 ${
                      location.pathname === item.path
                        ? 'bg-[#7d2ae8]/10 text-[#7d2ae8] dark:bg-[#238636]/20 dark:text-[#3fb950]'
                        : 'text-gray-600 hover:bg-gray-100 dark:text-[#8b949e] dark:hover:bg-[#21262d] dark:hover:text-[#e6edf3]'
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span>{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-gray-100 dark:bg-[#21262d] hover:bg-gray-200 dark:hover:bg-[#30363d] transition-colors"
                title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
              >
                {theme === 'light' ? (
                  <svg className="w-5 h-5 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5 text-[#e6edf3]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                )}
              </button>
              
              {/* User Info */}
              <div className="hidden md:block text-right">
                <p className="text-sm font-semibold text-gray-900 dark:text-[#e6edf3]">{user?.full_name || user?.email}</p>
                <p className="text-xs text-gray-500 dark:text-[#8b949e]">{user?.role}</p>
              </div>
              
              {/* Logout */}
              <button
                onClick={logout}
                className="px-4 py-2 text-sm font-medium rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-[#21262d] dark:hover:bg-[#30363d] text-gray-700 dark:text-[#e6edf3] transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 custom-scrollbar">
        {children}
      </main>
    </div>
  )
}
